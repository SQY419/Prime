import ustruct as struct
import uio
import hpprime

minit = 'Ter:={};/n/nEXPORT UReset()/nBEGIN/n  DIMGROB_P(G1,320,240);/n  Ter:={}; /nEND;/n/n /n  /nEXPORT Clean(g,c)/nBEGIN/n  RECT_P(g,c);/nEND;/n/n /n/nEXPORT Print00(t,g,x,y,c)/nBEGIN/n  TEXTOUT_P(t,g,x,y,{""2D"",0,c});/nEND;/n/n/nEXPORT AddIn(t)/nBEGIN/n  IF DIM(t) ≤ 53 THEN/n    Ter:=CONCAT(Ter,t);/n  ELSE/n    LOCAL k:=1;/n    WHILE k ≤ DIM(t) DO/n      Ter:=CONCAT(Ter,MID(t,k,53));/n      k:=k+53;/n    END;/n  END;/nEND;/n/n/nEXPORT UTerInit(g,c)/nBEGIN/n  LOCAL l:=IFTE(SIZE(Ter) ≤ 24,1,SIZE(Ter)-23),y:=1;/n  Clean(g,c);/n  WHILE l ≤ SIZE(Ter) DO/n    Print00("" ""+Ter[l]+""                                                      "",g,-12,y,#FFFFFFh);/n    l:=l+1;/n    y:=y+10;/n  END;/n  BLIT_P(g);/nEND;/n'.replace("/n","\n")
hpprime.eval('print;')


if not "MiniTerminal" in hpprime.eval("Programs()"):
    hpprime.eval('Programs("MiniTerminal"):="' + minit + '"')


print("use hpapp program...")
print("gbemu will boot in 1 second...")
try:
    hpprime.eval("WAIT(1);gbemu_main();")
except KeyboardInterrupt:
    ...


"""
# ORIGINAL CODE
def trans(text):
    return text.replace('"','""').replace('\\','\\\\') 
 

def myprint(text = ""):
    hpprime.eval('AddIn("' + trans(text) + '")')
    hpprime.eval('UTerInit()') 
    
    
    #if len(text) <= 52: 
    #    hpprime.eval('print2d("' + trans(text) + '", 0)')
    #else:
    #    for i in range(int(len(text) / 52)):
    #        hpprime.eval('print2d("' + trans(text[i*52: i*52 + 52]) + '", 0)')
    #    hpprime.eval('print2d("' + trans(text[52 * int(len(text) / 52):]) + '", 0)') 
    

def iskeydown(k):
    return hpprime.keyboard() & (1 << k)


print = myprint


class PrimeDebug:
    def __init__(self, filename="debug"):
        try:
            self.f = uio.FileIO("debug")
        except:
            self.f = open(filename, "rb")
        print("[+] Debug interface opened.")

    def close(self):
        if self.f: self.f.close()

    def write_mem(self, addr, val):
        self.f.write(struct.pack("<III", 1, addr, val))

    def read_mem(self, addr, size):
        self.f.write(struct.pack("<III", 0, addr, 0))
        return self.f.read(size)

    def call(self, func_addr, *args):
        arg_count = len(args)
        fmt = "<III" + "I" * arg_count
        buf = bytearray(struct.calcsize(fmt))
        struct.pack_into(fmt, buf, 0, 2, func_addr, arg_count, *args)
        self.f.write(buf)
        return struct.unpack_from("<I", buf, 0)[0]

    def write_mem_bytes(self, addr, data):
        pad_len = (4 - (len(data) % 4)) % 4
        data += b'\x00' * pad_len
        for i in range(0, len(data), 4):
            val = struct.unpack("<I", data[i:i+4])[0]
            self.write_mem(addr + i, val)


BASE = 0x307FBCAC
def get_addr(int_id):
    return BASE + 0xC * (int_id - 0x10000)

ADDR_MALLOC = get_addr(0x10037)
ADDR_FREE   = get_addr(0x1003A)

class ElfTools:
    @staticmethod
    def str_to_utf16le_bytes(s):
        res = bytearray()
        for char in s:
            val = ord(char)
            res.append(val & 0xFF)
            res.append((val >> 8) & 0xFF)
        res.append(0); res.append(0)
        return bytes(res)

    @staticmethod
    def get_elf_memory_size(filename):
        required_size = 0
        f = None
        try:
            f = uio.FileIO(filename, "rb")
            ehdr = f.read(52)
            if len(ehdr) < 52 or ehdr[0:4] != b'\x7fELF':
                print("[-] Invalid ELF header")
                return 0
            
            e_phoff, e_phentsize, e_phnum = struct.unpack_from("<IHH", ehdr, 28)
            f.seek(e_phoff)
            PT_LOAD = 1
            for i in range(e_phnum):
                ph_data = f.read(e_phentsize)
                p_type = struct.unpack_from("<I", ph_data, 0)[0]
                p_vaddr = struct.unpack_from("<I", ph_data, 8)[0]
                p_memsz = struct.unpack_from("<I", ph_data, 20)[0]
                
                if p_type == PT_LOAD:
                    end_addr = p_vaddr + p_memsz
                    if end_addr > required_size:
                        required_size = end_addr
        except Exception as e:
            print("[-] Error parsing ELF: " + str(e))
            return 0
        finally:
            if f:
                f.close()
        
        return (required_size + 3) & ~3

class ShellcodeElfLoader:
    def __init__(self, dbg):
        self.dbg = dbg
        self.loader_addr = 0
        self.loaded_elf_base = 0
        self.entry_point = 0
        self.loader_code = b'\x0b\x00\x00\xea\x04\x00-\xe5\x04\xe0-\xe5o\x02\x01\xef\x04\x00-\xe5\x04\xe0-\xe5\xca\x00\x01\xef\x04\x00-\xe5\x04\xe0-\xe5\xd4\x00\x01\xef\x04\x00-\xe5\x04\xe0-\xe5\xcf\x00\x01\xefh2\x9f\xe5\xf0O-\xe9\x030\x8f\xe0\x00 \xa0\xe1\x01`\xa0\xe1\x03\x00\x93\xe8d\xd0M\xe2\x04\x00\x8d\xe5\xb8\x10\xcd\xe1\x02\x00\xa0\xe1\x04\x10\x8d\xe2\xe7\xff\xff\xeb\x00@P\xe2s\x00\x00\n\x040\xa0\xe1\x01 \xa0\xe34\x10\xa0\xe3,\x00\x8d\xe2\xe6\xff\xff\xeb\x01\x00P\xe3j\x00\x00\x1a\xbc"\xdd\xe1\x142\x9f\xe5\x03\x00R\xe1f\x00\x00\x1aH\x10\x9d\xe5\x00 \xa0\xe3\x04\x00\xa0\xe1\xdf\xff\xff\xeb\xb85\xdd\xe1\x00\x00S\xe3x\x00\x00\n\x00P\xa0\xe3\x05p\xa0\xe1\x0c\xa0\x8d\xe2\x04\x00\x00\xea\xb85\xdd\xe1\x02\x00[\xe3\x14p\x9d\x05\x05\x00S\xe1\x19\x00\x00\xda\x040\xa0\xe1\x01 \xa0\xe3 \x10\xa0\xe3\n\x00\xa0\xe1\xcb\xff\xff\xeb\x0c\xb0\x9d\xe5\x01P\x85\xe2\x01\x00[\xe3\xf1\xff\xff\x1a\x1c0\x9d\xe5\x14\x80\x9d\xe5H\x90\x9d\xe5\x00\x00S\xe3\x08\x80\x86\xe0\x85\x92\x89\xe0K\x00\x00\x1a  \x9d\xe5\x03\x00R\xe1U\x00\x00\x8a\t\x10\xa0\xe1\x00 \xa0\xe3\x04\x00\xa0\xe1\xbc\xff\xff\xeb\xb85\xdd\xe1\x05\x00S\xe1\xe5\xff\xff\xca\x04\x00\xa0\xe1\xb1\xff\xff\xeb\x00\x00W\xe3/\x00\x00\n\x070\x96\xe7\x07p\x86\xe0\x00\x00S\xe3+\x00\x00\n\x00 \xa0\xe3\x08\xc0\xa0\xe3\x02\x00\xa0\xe1\x02\xe0\xa0\xe1\x11\x00S\xe3\x04\xe0\x97\x05\x04\x00\x00\n\x12\x00S\xe3\x04\x00\x97\x05\x01\x00\x00\n\x13\x00S\xe3\x04\xc0\x97\x05\x080\xb7\xe5\x01 \x82\xe2\x00\x00S\xe3d\x00R\x13\x01\x10\xa0\x13\x00\x10\xa0\x03\xf0\xff\xff\x1a\x00\x00^\xe3\x00\x00P\x13\x15\x00\x00\n\x00\x00\\\xe3\x08\xc0\xa0\x03\x0c\x00P\xe1\x11\x00\x00:\x0c\x00@\xe0\x00\x00\\\xe1\x01\x10\x81\xe2\xfb\xff\xff\x9a\x00\x00Q\xe3\x0b\x00\x00\n\x81\x11\x86\xe0\x0e0\x86\xe0\x0e\x10\x81\xe0\x04 \xd3\xe5\x080\x83\xe2\x17\x00R\xe3\x08\x00\x13\x05\x00 \x96\x07\x02 \x86\x00\x00 \x86\x07\x01\x00S\xe1\xf6\xff\xff\x1a\x000\xa0\xe3~\xff\x17\xee\xfd\xff\xff\x1a\x9a?\x07\xee\x15?\x07\xeeD0\x9d\xe5\x03\x00\x86\xe0d\xd0\x8d\xe2\xf0\x8f\xbd\xe8\x04\x00\xa0\xe1t\xff\xff\xeb\x00\x00\xa0\xe3d\xd0\x8d\xe2\xf0\x8f\xbd\xe8\x10\x10\x9d\xe5\x00 \xa0\xe3\x04\x00\xa0\xe1s\xff\xff\xeb\x1c \x9d\xe5\x040\xa0\xe1\x0b\x10\xa0\xe1\x08\x00\xa0\xe1k\xff\xff\xeb\x1c0\x9d\xe5  \x9d\xe5\x03\x00R\xe1\xa9\xff\xff\x9a\x030\x88\xe0\x02\x80\x88\xe0\x00 \xa0\xe3\x01 \xc3\xe4\x08\x00S\xe1\xfc\xff\xff\x1a\xa2\xff\xff\xea\x04\x00\xa0\xe1[\xff\xff\xeb\xda\xff\xff\xeah\x02\x00\x00\x7fE\x00\x00r\x00b\x00\x00\x00'

    def upload_loader(self):
        size = len(self.loader_code)
        print("[*] Allocating loader shellcode ({} bytes)...".format(size))
        self.loader_addr = self.dbg.call(ADDR_MALLOC, (size + 3) & ~3)
        if not self.loader_addr: return False
        print("[*] Uploading loader to 0x{:08X}".format(self.loader_addr))
        self.dbg.write_mem_bytes(self.loader_addr, self.loader_code)
        return True

    def load_elf(self, filename, app_dir):
        # 修改：python侧访问 filename, C侧访问 app_dir + filename
        print("[*] Loading ELF: {}".format(filename))
        mem_size = ElfTools.get_elf_memory_size(filename)
        if mem_size == 0: return None
        print("[*] ELF requires memory: {} bytes".format(mem_size))
        self.loaded_elf_base = self.dbg.call(ADDR_MALLOC, mem_size)
        if not self.loaded_elf_base: return None
        print("[*] Allocated Target Memory at: 0x{:08X}".format(self.loaded_elf_base))
        
        # 准备shellcode需要的完整路径
        full_path_for_c = app_dir + "\\" + filename
        path_bytes = ElfTools.str_to_utf16le_bytes(full_path_for_c)
        path_addr = self.dbg.call(ADDR_MALLOC, len(path_bytes))
        self.dbg.write_mem_bytes(path_addr, path_bytes)
        
        try:
            print("[*] Calling shellcode loader...")
            # Shellcode的第一个参数是C代码需要的文件路径
            self.entry_point = self.dbg.call(self.loader_addr, path_addr, self.loaded_elf_base)
            print("[+] Shellcode returned Entry Point: 0x{:08X}".format(self.entry_point))
            if self.entry_point < 0x30000000: return None
            return self.entry_point
        finally:
            if path_addr: self.dbg.call(ADDR_FREE, path_addr)
    
    def unload(self):
        if self.loaded_elf_base: self.dbg.call(ADDR_FREE, self.loaded_elf_base)
        if self.loader_addr: self.dbg.call(ADDR_FREE, self.loader_addr)

class LogReader:
    def __init__(self, debug_interface, log_struct_addr):
        self.dbg = debug_interface
        self.addr = log_struct_addr
        self.local_head = 0
        self.log_size = 4096 # Must match C code's LOG_BUFFER_SIZE

    def process(self):
        try:
            head_bytes = self.dbg.read_mem(self.addr, 4)
            remote_head = struct.unpack("<I", head_bytes)[0]
        except Exception as e:
            return

        if remote_head > self.local_head:
            start_idx = self.local_head % self.log_size
            end_idx = remote_head % self.log_size
            new_data = b""
            if end_idx > start_idx:
                data_addr = self.addr + 4 + start_idx
                new_data = self.dbg.read_mem(data_addr, end_idx - start_idx)
            else:
                len1 = self.log_size - start_idx
                if len1 > 0: new_data += self.dbg.read_mem(self.addr + 4 + start_idx, len1)
                if end_idx > 0: new_data += self.dbg.read_mem(self.addr + 4, end_idx)
            
            for dat in str(new_data).split('\\n'):
                print(str(dat).replace("b'","").replace("'",""))
            
            self.local_head = remote_head

class AppConfigBuilder:
    def __init__(self, dbg, app_dir):
        self.dbg = dbg
        self.app_dir = app_dir
        self.allocations = []
        self.args = ["my_app", "-iwad", self.app_dir + "\\doom1.wad"]
        self.envs = {"HOME": self.app_dir}
        self.keys = []

    def _alloc_str(self, s):
        b = s.encode('utf-8') + b'\x00'
        size = (len(b) + 3) & ~3
        addr = self.dbg.call(ADDR_MALLOC, size)
        self.dbg.write_mem_bytes(addr, b)
        self.allocations.append(addr)
        return addr

    def _alloc_ptr_array(self, pointers):
        size = len(pointers) * 4
        if size == 0: return 0
        addr = self.dbg.call(ADDR_MALLOC, size)
        pack_format = "<" + "I" * len(pointers)
        self.dbg.write_mem_bytes(addr, struct.pack(pack_format, *pointers))
        self.allocations.append(addr)
        return addr

    def build(self):
        print("[*] Building configuration structure...")
        arg_ptrs = [self._alloc_str(x) for x in self.args]
        argv_addr = self._alloc_ptr_array(arg_ptrs)
        
        env_array_addr = 0
        key_array_addr = 0

        config_size = 28 # 7 * 4 bytes
        config_addr = self.dbg.call(ADDR_MALLOC, config_size)
        
        MAGIC = 0xD00BC760 
        payload = struct.pack("<IIIIIII", MAGIC, len(self.args), argv_addr, len(self.envs), env_array_addr, len(self.keys), key_array_addr)
        self.dbg.write_mem_bytes(config_addr, payload)
        self.allocations.append(config_addr)
        
        print("[+] Config built at: 0x{:08X}".format(config_addr))
        return config_addr

    def free_all(self):
        for addr in reversed(self.allocations):
            self.dbg.call(ADDR_FREE, addr)
        self.allocations = []


def run_app(elf_filename, app_dir_for_c, enable_config=True, enable_logging=True):
    print()
    print("                HP Prime GameBoy Emu")
    print()
    print("--- Loader ---")
    print("  - MiniTerminal v0")
    print("  - App: " + elf_filename)
    print("  - Config enabled: " + str(enable_config))
    print("  - Logging enabled: " + str(enable_logging))
    
    dbg = None
    loader = None
    config_builder = None
    
    try:
        dbg = PrimeDebug()
        loader = ShellcodeElfLoader(dbg)
        
        if not loader.upload_loader():
            raise RuntimeError("Failed to upload shellcode loader")
        
        entry_point = loader.load_elf(elf_filename, app_dir_for_c)
        if not entry_point:
            raise RuntimeError("Failed to load ELF file")

        config_addr = 0
        if enable_config:
            config_builder = AppConfigBuilder(dbg, app_dir_for_c)
            config_addr = config_builder.build()
        else:
            print("[*] Skipping config creation.")

        print("[*] Calling entry point 0x{:08X}".format(entry_point))
        print("    config_addr=0x{:08X}".format(config_addr))
        
        print()
        print("    >>> Press Enter to start... <<<")
        print()
        while not(iskeydown(30) or iskeydown(4)): 
            ...
            
        if iskeydown(4):
             return
        
        log_addr = dbg.call(entry_point, config_addr, 0)
        print("[+] log structure address: 0x{:08X}".format(log_addr))

        if not enable_logging:
            print("[*] Logging is disabled. Script will now exit.")
            return

        if log_addr < 0x30000000:
             print("[!] Invalid log address returned. C code may have crashed early.")
             return

        logger = LogReader(dbg, log_addr)
        print("--- Streaming Logs ---")
        while True:
            logger.process()
            start_ticks = hpprime.ticks()
            while hpprime.ticks() - start_ticks < 100: # 延时约100ms
                pass

    except KeyboardInterrupt:
        print("[!] Interrupted by user.")
    except Exception as e:
        print("[!!] An error occurred: " + str(e))
    finally:
        print("--- Shutdown loader ---")
        if config_builder: config_builder.free_all()
        if loader: loader.unload()
        if dbg: dbg.close()
        print("--- Shutdown complete. ---")


# Python脚本访问ELF文件的名称
APP_ELF_FILENAME = "my_app.elf" 
APP_DIR_FOR_C_CODE = r"C:\DATA\gbemu.hpappdir"

hpprime.eval("UReset()")
run_app(APP_ELF_FILENAME, APP_DIR_FOR_C_CODE, enable_config=True, enable_logging=True)

"""