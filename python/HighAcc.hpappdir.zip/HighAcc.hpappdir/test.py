'''
from main import *
from hpprime import eval as he
t=he("TICKS()")
k=fl_asin('1.0')
print(he("TICKS()")-t)
#print(a)
a=highacc('1.0')
b=fl_sqrt('0.5')
c=highacc('0.25')
d=highacc(1)
#print(he("TICKS()")-t)
for i in range(10):
    a0=highacc('0.5')*(a+b)
    b0=fl_sqrt(a*b)
    c=c-d*(a-a0)**2
    d=d*2
    a,b=a0,b0
    #print(he("TICKS()")-t)
s=(a+b)**2/(highacc('4.0')*c)
print(he("TICKS()")-t)
#print(s)
'''